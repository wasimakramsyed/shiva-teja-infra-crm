from django.shortcuts import (
    render,
    get_object_or_404,
)

from django.db.models import Q

from accounts.decorators import role_required

from commissions.models import CommissionRecord


@role_required(["admin", "accounts", "manager"])
def commission_list(request):

    query = request.GET.get("q", "")
    status_filter = request.GET.get("status")

    commissions = (
        CommissionRecord.objects
        .select_related(
            "booking",
            "customer",
            "project",
            "plot",
            "request",
        )
        .order_by("-created_at")
    )

    if query:

        commissions = commissions.filter(

            Q(record_id__icontains=query) |

            Q(booking__booking_id__icontains=query) |

            Q(customer__customer_name__icontains=query)

        )

    if status_filter:

        commissions = commissions.filter(
            status=status_filter
        )

    return render(

        request,

        "commissions/commission_list.html",

        {

            "commissions": commissions,

            "query": query,

            "status_filter": status_filter,

        },

    )


@role_required(["admin", "accounts", "manager"])
def commission_profile(request, commission_id):

    commission = get_object_or_404(

        CommissionRecord.objects.select_related(

            "booking",
            "customer",
            "project",
            "plot",
            "request",

        ),

        id=commission_id,

    )

    return render(

        request,

        "commissions/commission_profile.html",

        {

            "commission": commission,

        },

    )