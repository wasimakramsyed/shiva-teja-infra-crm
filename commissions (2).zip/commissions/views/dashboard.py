from django.shortcuts import render

from accounts.decorators import role_required


@role_required(["admin", "accounts"])
def commission_dashboard(request):

    return render(

        request,

        "commissions/commission_dashboard.html",

    )