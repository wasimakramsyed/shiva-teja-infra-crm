from decimal import Decimal
from urllib import request

from django.db import transaction
from django.utils import timezone

from commissions.models import (
    CommissionRecord,
    CommissionAllocation,
)

from .calculator import CommissionCalculator
from .timeline_service import CommissionTimelineService
from .allocation_service import CommissionAllocationService


class CommissionGeneratorService:

    @staticmethod
    @transaction.atomic
    def generate(
        request,
        commission_percentage,
        tds_percentage,
        allocations,
        generated_by,
        other_deduction=0,
        remarks=""
    ):
        # ============================================
# Validate Allocation
# ============================================

        if not allocations:

            raise ValueError(
                "No commission allocation found."
            )

        if request.status != "ready":
            raise ValueError(
                "Commission has already been processed."
            )
        

        if hasattr(request, "record"):
            raise ValueError(
                "Commission Record already exists."
            )

        calculation = CommissionCalculator.calculate(
            sale_amount=request.sale_amount,
            commission_percentage=commission_percentage,
            tds_percentage=tds_percentage,
            other_deduction=other_deduction,
        )

        commission = CommissionRecord.objects.create(

            request=request,

            booking=request.booking,

            customer=request.customer,

            customer_property=request.customer_property,

            project=request.project,

            plot=request.plot,

            sale_amount=request.sale_amount,

            commission_percentage=commission_percentage,

            gross_commission=calculation["gross_commission"],

            tds_percentage=tds_percentage,

            tds_amount=calculation["tds_amount"],

            other_deduction=other_deduction,

            net_commission=calculation["net_commission"],

            generated_by=generated_by,

            remarks=remarks,
        )
        total_percentage = Decimal("0")

        for allocation in allocations:

            total_percentage += Decimal(
                str(allocation["percentage"])
            )

        if total_percentage != Decimal("100"):

            raise ValueError(
                "Allocation percentage must equal 100."
            )

        for allocation in allocations:

            percentage = Decimal(
                str(allocation["percentage"])
            )

            gross_amount = (
            calculation["gross_commission"]
            * percentage
            ) / Decimal("100")

            tds_amount = (
            calculation["tds_amount"]
            * percentage
            ) / Decimal("100")

            net_amount = (
            calculation["net_commission"]
            * percentage
            ) / Decimal("100")

            CommissionAllocationService.create(

                commission=commission,

                employee=allocation["employee"],

                percentage=percentage,

                gross_amount=gross_amount,

                tds_amount=tds_amount,

                net_amount=net_amount,

            )

        CommissionTimelineService.create(

            commission=commission,

            activity="Commission Generated",

            created_by=generated_by,

            remarks=remarks,

        )

        request.status = "generated"

        request.generated_by = generated_by
        request.generated_at = timezone.now()

        request.save()

        return commission
    